package cloud.sect.alm.event;

import cloud.sect.alm.Config;
import cloud.sect.alm.keybinding.LoginKeybinding;
import net.minecraft.class_2561;

public class ClientTickEvents {
    public static void register() {
        net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (LoginKeybinding.get().method_1436()) {
                if (client.field_1724 != null) {
                    String command = Config.getCommand();
                    if (command.isEmpty()) {
                        client.field_1724.method_7353(class_2561.method_43471("alm.default_command_text"), false);
                        continue;
                    }
                    client.field_1724.field_3944.method_45730(command);
                }
            }
        });
    }
}
