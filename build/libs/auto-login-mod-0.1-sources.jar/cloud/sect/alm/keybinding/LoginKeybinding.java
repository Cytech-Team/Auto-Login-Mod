package cloud.sect.alm.keybinding;

import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class LoginKeybinding {
    private static class_304 loginKeyBinding;

    public static void register() {
        loginKeyBinding = KeyBindingHelper.registerKeyBinding(new class_304(
                "alm.key.autocmd.send",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_F9,
                class_304.class_11900.field_62556
        ));
    }

    public static class_304 get() {
        return loginKeyBinding;
    }
}
